import{c as r,s as e}from"./flowDiagram-23GEKE2U-CVBd7Rlm.js";import{_ as a}from"./mermaid.core-DezNLUUv.js";import"./index-B7bHCBy8.js";import"./chunk-5VM5RSS4-BqQ8N7a5.js";import"./chunk-XXDRQBXY-WrfxuUJ_.js";import"./chunk-VR4S4FIN-Bppo3y52.js";import"./chunk-32BRIVSS-DOd44dkr.js";import"./channel-CH16ZrUp.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
